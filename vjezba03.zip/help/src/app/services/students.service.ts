import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

@Injectable()
export class StudentsService {

  students: Student[] = [
    {jmbag: '023242123', ectsCount: 127, isPayingTuition: false},
    {jmbag: '023232123', ectsCount: 27, isPayingTuition: true},
    {jmbag: '023242122', ectsCount: 137, isPayingTuition: false},
    {jmbag: '023241123', ectsCount: 87, isPayingTuition: true},
  ];

  constructor() { }

  public getStudents(): Observable<Student[]> {
    return Observable.of(this.students);
  }
}

export interface Student {
  jmbag: String;
  ectsCount: number;
  isPayingTuition: boolean;
}
