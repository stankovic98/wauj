create table students (
    jmbag varchar(10) primary key,
    name varchar(30),
    surname varchar(30),
    ectsCount int,
    dateOfBirth DATE
);
