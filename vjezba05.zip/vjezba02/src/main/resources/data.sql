insert into students (jmbag, name, surname, ectsCount, dateOfBirth) VALUES (
    '1234567890', 'Franjo', 'Kempinac', 12, '25.03.1998',
    '1234567891', 'Josip', 'Kempinac', 185, '25.03.1997',
    '1234567892', 'Ivan', 'Kempinac', 292, '25.03.1994',
)
