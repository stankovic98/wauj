package hr.tvz.stankovic.studapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudappApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudappApplication.class, args);
    }

}
