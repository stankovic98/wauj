package hr.tvz.stankovic.studapp;

import java.util.List;

public interface StudentService {
    List<StudentDTO> findAll();
    List<StudentDTO> findTuitionFreeStudents();
    StudentDTO findStudentByJMBAG(String jmbag);
}
