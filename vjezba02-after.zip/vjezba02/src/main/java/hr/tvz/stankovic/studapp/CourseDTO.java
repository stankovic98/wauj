package hr.tvz.stankovic.studapp;

public class CourseDTO {
    String name;
    int ectsCount;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEctsCount() {
        return ectsCount;
    }

    public void setEctsCount(int ectsCount) {
        this.ectsCount = ectsCount;
    }

    public CourseDTO(String name, int ectsCount) {
        this.name = name;
        this.ectsCount = ectsCount;
    }
}
