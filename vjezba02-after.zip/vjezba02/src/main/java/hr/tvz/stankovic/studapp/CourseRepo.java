package hr.tvz.stankovic.studapp;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Repository
public class CourseRepo {
    private List<Course> MOCKED_COURSES = new ArrayList<>(Arrays.asList(
            new Course("123", "Matematika", 6), new Course("124", "Programiranje u Go-u", 9)
    ));

    public List<Course> findAll() {
        return this.MOCKED_COURSES;
    }

    public Optional<Course> update(CourseCommand newCourse) {
        if (this.MOCKED_COURSES.stream().filter(course -> course.getId().equals(newCourse.getId())).findAny().orElse(null) == null) {
            return Optional.empty();
        }
        MOCKED_COURSES.add(new Course(newCourse));
        return Optional.of(new Course(newCourse));
    }
}
