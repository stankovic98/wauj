package hr.tvz.stankovic.studapp;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CourseService {
    private final CourseRepo courseRepo;

    public CourseService(CourseRepo repo) {
        this.courseRepo = repo;
    }
    @GetMapping
    public List<CourseDTO> findAll() {
        return courseRepo.findAll().stream().map(this::courseToDTO).collect(Collectors.toList());
    }

    @PutMapping
    public CourseDTO update(CourseCommand course) {
        return this.courseRepo.update(course).stream().map(this::courseToDTO).findAny().orElse(null);
    }

    private CourseDTO courseToDTO(Course course) {
        return new CourseDTO(course.getName(), course.getEctsCount());
    }
}
