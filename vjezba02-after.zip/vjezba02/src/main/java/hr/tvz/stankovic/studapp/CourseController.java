package hr.tvz.stankovic.studapp;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("course")
public class CourseController {

    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @PutMapping("")
    public ResponseEntity<CourseDTO> update(@Valid @RequestBody final CourseCommand course){
        CourseDTO updatedCourse = courseService.update(course);
         if (updatedCourse == null) {
             return ResponseEntity.notFound().build();
         }
         return  ResponseEntity
                .status(HttpStatus.OK)
                .body(updatedCourse);
    }
}
