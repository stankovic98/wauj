package hr.tvz.stankovic.studapp;

public class Course {

    String id;
    String name;
    int EctsCount;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEctsCount() {
        return EctsCount;
    }

    public void setEctsCount(int ectsCount) {
        EctsCount = ectsCount;
    }

    public Course(String id, String name, int ectsCount) {
        this.id = id;
        this.name = name;
        EctsCount = ectsCount;
    }

    public Course(CourseCommand course) {
        this.id = course.getId();
        this.name = course.getName();
        EctsCount = course.getEctsCount();
    }
}
