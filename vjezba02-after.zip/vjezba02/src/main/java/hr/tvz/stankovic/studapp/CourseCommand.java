package hr.tvz.stankovic.studapp;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;

public class CourseCommand {

    @NotNull(message ="ID must not be emtpy")
    String id;

    @NotNull(message ="Name must not be emtpy")
    String name;

    @NotNull(message ="Ects number must not be emtpy")
    @PositiveOrZero(message = "Number of ECTS must be entered as a positive integer")
    @Max(message = "Number of ECTS can not be higher than 33", value = 33)
    int EctsCount;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEctsCount() {
        return EctsCount;
    }

    public void setEctsCount(int ectsCount) {
        EctsCount = ectsCount;
    }

    public CourseCommand(String id, String name, int ectsCount) {
        this.id = id;
        this.name = name;
        EctsCount = ectsCount;
    }
}
